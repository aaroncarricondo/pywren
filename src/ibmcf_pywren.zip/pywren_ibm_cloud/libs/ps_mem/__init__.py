from pywren_ibm_cloud.libs.ps_mem.ps_mem import *

__version__ = '3.13'
